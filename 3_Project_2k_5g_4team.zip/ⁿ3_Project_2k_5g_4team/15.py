import numpy as np

x = np.array([1, 2, 3])
y = np.array([2, 4, 8])
s = np.dot(x, y)
print("Скалярное произведение: ",s)