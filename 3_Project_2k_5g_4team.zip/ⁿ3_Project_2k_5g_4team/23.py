import numpy as np

x = np.array([[6, 2, 3, 4], [5, 1, 7, 8]])
print("Массив -", x);
print("Произведение всех элементов -", np.nanprod(x))
print("Стандартное отклонение -", np.nanstd(x))
print("Индекс минимального значения -", np.argmin(x))

