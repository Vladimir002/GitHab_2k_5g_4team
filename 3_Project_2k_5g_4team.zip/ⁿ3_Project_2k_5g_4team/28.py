import numpy as np


def ArrPrint(a):
    for i in a:
        print(i, end=" ")
    print()


n = int(input("Число элементов в массиве >>> "))
a = np.random.randint(-10, 20, n)

print("Исходный массив")
ArrPrint(a)

b = np.where(-1 < a, a, 11)
b = np.where(b < 11, b, -1)

b = list(b)

while -1 in b:
    b.remove(-1)

print("Итоговый массив")
ArrPrint(b)