import numpy as np
a = np.array([1,4,5,2,3])
print('Заданный массив: ',a)
print('Тип: ',a.dtype)
print('Размерность: ',a.ndim)
print('Размер каждого измерения: ',a.shape)
print('Количество элементов: ',a.size)
print('Количество байт на один элемент: ',a.itemsize)
print('Количество байт на весь массив: ',a.nbytes)
