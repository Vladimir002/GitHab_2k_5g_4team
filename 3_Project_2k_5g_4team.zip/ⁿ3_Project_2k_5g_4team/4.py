import numpy as np
a = np.random.rand(5)
b = np.random.rand(5)
print(a,b,sep = "\n")
