import numpy as np

A = np.array(
     [
         [-8, -5, 6],
         [18, 11, -13],
         [1, 1, -1],
    ]
)
try:
    inverse = np.linalg.inv(A)
except np.linalg.LinAlgError:
    print("Нельзя")
    pass
else:
    print(inverse)