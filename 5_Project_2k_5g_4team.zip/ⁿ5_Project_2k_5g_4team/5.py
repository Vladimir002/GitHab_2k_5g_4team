from sympy import *

#1.4 Вычисление пределов
n = Symbol('n')
f1_1 = limit( ( factorial(n)*exp(n) )/( (n**n)*sqrt(n) ),n,oo)
f1_2 = limit( ( factorial(n)*exp(n) )/( (n**n)*sqrt(n) ),n,oo).evalf()
print(f1," = ",f2)

#2.1 Вычисление рядов
var('n2')
f2_1 = summation((1/4)**n2,(n2,1,oo))
print(f2_1)

#3.4 Вычисление производных
x1 = Symbol('x1')
f3_1 = diff(x1**x1,x1)
print(f3_1)

#4.2 Вычисление интегралов
x2 = Symbol('x2')
f4_1 = integrate( (x**2)*sin(x), x)
print(f4_1)

#5.2
x3,y3 = symbols('x, y')
print(linsolve([tan(x3**2 - y3) - 0.48*(x3+y3), (x3-0.2)**2 - 3*y3**2 - 1.5],x3>0,y3>0))

#6.3
from sympy.plotting import plot
x = Symbol('x')
p1=plot(x**7 + 7*x**5 + 3*x**4 + 5*x**3 + 26*x**2 - 10*x + 40,(x,-10,10))