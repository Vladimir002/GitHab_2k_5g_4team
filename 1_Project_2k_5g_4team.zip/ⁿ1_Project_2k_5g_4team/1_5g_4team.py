from tkinter import * # подключаем tkinter
from tkinter.messagebox import *
""""Поменять цвета фона фреймов и текста на них, изменить курсор при
наведении на какой-то из фреймов."""

root = Tk( )
root.minsize(width = 350, height = 150)
root.maxsize(width = 500, height = 300)
root.title("Калькулятор")

fr_xy = Frame(root)
fr_xy.pack(side = TOP, expand = YES, fill = X)
lx = Label(fr_xy, text = "x = ", bg='green yellow',fg="red")
lx.pack(side = LEFT, padx = 10, pady = 10)
entX = Entry(fr_xy,bg = "green yellow",fg = "red")
entX.insert(0, 0)
entX.pack(side = LEFT, padx = 10, pady = 10)
entX.focus( )
ly = Label(fr_xy, text = "y = ", bg='green yellow',fg="red")
ly.pack(side = LEFT, padx = 10,pady = 10)
entY = Entry(fr_xy,bg = "green yellow",fg = "red")
entY.insert(0, 0)
entY.pack(side = LEFT, padx = 10, pady = 10)
fr_xy.config(bg='green', cursor="box_spiral")



fr_op = LabelFrame(root, text = "Операция:",fg = "red")
fr_op.pack(side = TOP, expand = YES, fill = X)
oper = ['+', '-', '*', '/']
varOper = StringVar( )
for op in oper:
    Radiobutton(fr_op, text = op, variable = varOper,
    value = op, bg='green yellow',fg="red").pack(side = LEFT,padx = 20, pady = 10)
varOper.set(oper[0])
fr_op.config(bg='green', cursor="circle")

fr_res = Frame(root)
fr_res.pack(side = TOP, expand = YES, fill = BOTH)
def OnButtunResult( ):
    try:
        x = float(entX.get())
    except ValueError:
        showerror("Ошибка","Переменная x не является числом")
        return
    try:
        y = float(entY.get())
    except ValueError:
        showerror("Ошибка","Переменная y не является числом")
        return
    op = varOper.get( )
    if op == '+':   res = x + y
    elif op == '-': res = x - y
    elif op == '*': res = x * y
    elif op == '/':
        if y != 0: res = x / y
        else:      res = 'NAN'
    else:
        res = 'операция выбрана неправильно'
    lres['text'] = res
fr_res.config(bg='green', cursor="center_ptr")

b1 = Button(fr_res, text = "=", width = 10,
 command = OnButtunResult,activebackground = "yellow",
 activeforeground = "yellow", bg='green yellow',fg="red")
b1.pack(side = LEFT, padx = 30, pady = 20)
lres = Label(fr_res, text = "",bg = "green yellow",fg = "red")
lres.pack(side = LEFT, padx = 30, pady = 20)
root.mainloop( )