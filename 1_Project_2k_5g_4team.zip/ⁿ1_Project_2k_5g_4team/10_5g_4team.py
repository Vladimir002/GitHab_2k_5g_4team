from math import sqrt
from tkinter import *
from tkinter.messagebox import * # подключаемдиалоговыеокнаtkinter
from sympy import Symbol, solve, Eq, pprint

root = Tk()
root.minsize(width = 350, height = 150)
root.maxsize(width = 1500, height = 300)
root.title("Калькулятор")

fr_xy = LabelFrame(root, text = 'Коэффициенты', bg = 'lightblue',cursor = "target")
fr_xy.pack(side = TOP, expand = YES, fill = X)

la = Label(fr_xy, text = "a = ", bg = 'grey')
la.pack(side = LEFT, padx = 10,pady = 10)

entA = Entry(fr_xy)
entA.insert(0, 0)
entA.pack(side = LEFT, padx=10, pady=10)
entA.focus( )

lb = Label(fr_xy, text = "b = ",bg = 'grey')
lb.pack(side=LEFT, padx=10, pady=10)

entB = Entry(fr_xy)
entB.insert(0, 0)
entB.pack(side = LEFT, padx=10, pady=10)

lc = Label(fr_xy, text = "c = ", bg = 'grey')
lc.pack(side = LEFT, padx = 10,pady = 10)

entC = Entry(fr_xy)
entC.insert(0, 0)
entC.pack(side = LEFT, padx=10, pady=10)


fr_res = LabelFrame(root, text = 'Найти корни',bg = 'lightgreen')
fr_res.pack(side = TOP, expand = YES, fill = BOTH,)


def OnButtunResult( ):
    
    try:
        a = float(entA.get())
        
    except ValueError:
        showerror("Ошибка заполнения", "Переменная x не является числом")
        return
    
    try: b = float(entB.get())
    except ValueError:
        showerror("Ошибка заполнения", "Переменная y не является числом")
        return
    try: c = float(entC.get())
    except ValueError:
        showerror("Ошибка заполнения", "Переменная z не является числом")
        return
    if a == 0:
        raise showerror("Ошибка заполнения", "А не должно быть 0")

    
    d = b*b - 4 * a * c
    if d  > 0:
        x1 = (-b + sqrt(d))/(2*a)
        x2 = (-b - sqrt(d))/(2*a)
        lres['text'] = 'D > 0. 2 вещественных корня: '+'X1: {:5.2f}, X2: {:5.2f}'.format(x1,x2)
    elif d == 0:
        x1 = (-b)/(2*a)
        lres['text'] = 'D = 0. 1 вещественный корень: '+'X: {:5.2f}'.format(x1)
    else:
        lres['text'] = 'D < 0. Вещественных корней нет'
    
        
    
    
    
   

Button(fr_res, text = "=", width = 10, command = OnButtunResult).pack(side = LEFT, padx = 30, pady = 20)
lres = Label(fr_res, text = "")
lres.pack(side = LEFT, padx = 30, pady = 20)
root.mainloop()


