from tkinter import *
from PIL import Image, ImageTk
from tkinter import filedialog as fd

root = Tk()
root.title('Задание №28')
root.geometry("1000x600")
root.resizable(width=False, height=False)

canvas = Canvas(root, width=1000, height=600)
canvas.pack()

filename = fd.askopenfilename()
image = Image.open(fd.askopenfilename())
photo = ImageTk.PhotoImage(image)
canvas.create_image(10, 10, anchor=NW, image=photo)
root.mainloop()
