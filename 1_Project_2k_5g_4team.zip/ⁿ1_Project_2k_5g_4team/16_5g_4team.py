from tkinter import *
from tkinter.messagebox import *


root = Tk()
root.title("Опросник")
root.minsize(width = 350, height = 215)
root.maxsize(width = 350, height = 215)

StartPage = Frame(root)
Agreement = Frame(root)
PageThree = Frame(root)
FinalPage = Frame(root)

#размещаем все 4 фрейма, которые будем поднимать наверх с помощью raise_frame
for frame in (StartPage, Agreement, PageThree, FinalPage):
    frame.grid(row=0, column=0, sticky=N+E+S+W)

isagree = IntVar()
is18 = IntVar()
is18.set(-1)
black=IntVar()
white=IntVar()
red=IntVar()
green=IntVar()
yellow=IntVar()
blue=IntVar()


def raise_frame(frame):
    frame.tkraise()

#переключение состояния кнопки
def switch_btn(btn):
    btn.config(state=NORMAL if isagree.get() else DISABLED)

#кнопка закрытия программы
def closeQuery( ):
    if  askyesno('Выход из программы...', 'Закрыть программу? '):
        root.destroy(  )

#Функция в которой создается 4 страница
def res(frame):
    name="ФИО: %s"%ent.get()
    old="Старше 18" if is18.get() else "Младше 18"
    Colors="Цвета, которые нравятся:\n"+("Синий\n" if blue.get() else '')+("Жёлтый\n" if yellow.get() else '')+("Зелёный\n" if green.get() else '')+("Красный\n" if red.get() else '')+("Белый\n" if white.get() else '')+("Чёрный\n" if black.get() else '')
    Label(FinalPage, text='Результаты').pack()
    Label(FinalPage,text='%s'%name).pack()
    Label(FinalPage,text='%s'%old).pack()
    raise_frame(frame)
    Label(FinalPage,text='%s'%Colors).pack()
    Button(FinalPage,text="Выйти",command=closeQuery).pack()

#Первая страница
lab1 = Label(StartPage,height=1, text = "Опросник", fg  =  '#0000FF',   font   =   ('times', 30, 'bold'))
lab1.pack(side = TOP,expand = YES,fill=BOTH,pady=5)
Button(StartPage, text='Пройти опрос', command=lambda:raise_frame(Agreement)).pack(side=RIGHT,padx=5)
Button(StartPage,text="Выйти",command=closeQuery).pack(side=RIGHT)

#Вторая страница
Label(Agreement, text='Пользовательское соглашение').pack()
row1 = Frame(Agreement)
lab_1 = Label(row1, text='ФИО')
ent = Entry(row1)
row1.pack(side=TOP, fill=X)
lab_1.pack(side=LEFT)
ent.pack(side=RIGHT, fill=X,expand=YES) # растянуть по горизонтали
row2 = Frame(Agreement)
lab_2 = Label(row2, text='Вы старше 18?')
row2.pack(side=TOP,expand=YES,fill=X)
lab_2.pack(side=LEFT)


is18_radiobtn1 = Radiobutton(row2,text="Да", variable=is18,value=1)
is18_radiobtn2 = Radiobutton(row2,text="Нет", variable=is18,value=0)
is18_radiobtn1.pack(side=RIGHT)
is18_radiobtn2.pack(side=RIGHT)

isagree_checkbutton = Checkbutton(Agreement,text="Я согласен/согласна с обработкой персональных данных", variable=isagree,command=lambda:switch_btn(btn_next))
isagree_checkbutton.pack()


btn_next=Button(Agreement, text='Далее',state=DISABLED, command=lambda:raise_frame(PageThree))
btn_next.pack(side=RIGHT,padx=5)
Button(Agreement, text='Назад', command=lambda:raise_frame(StartPage)).pack(side=LEFT,padx=5)
Button(Agreement,text="Выйти",command=closeQuery).pack(side=RIGHT,)





#Третья страница
Label(PageThree, text=('Выберите все цвета которые вам нравятся')).pack()
b_blue=Checkbutton(PageThree,text='Синий',variable=blue,onvalue=1, offvalue=0)
b_white=Checkbutton(PageThree,text='Белый',variable=white,onvalue=1, offvalue=0)
b_black=Checkbutton(PageThree,text='Чёрный',variable=black,onvalue=1, offvalue=0)
b_red=Checkbutton(PageThree,text='Красный',variable=red,onvalue=1, offvalue=0)
b_yellow=Checkbutton(PageThree,text='Жёлтый',variable=yellow,onvalue=1, offvalue=0)
b_green=Checkbutton(PageThree,text='Зеленый',variable=green,onvalue=1, offvalue=0)

b_blue.pack()
b_green.pack()
b_black.pack()
b_white.pack()
b_yellow.pack()
b_red.pack()

Button(PageThree, text='Закончить опрос', command=lambda:res(FinalPage)).pack(side=RIGHT,padx=5)
Button(PageThree,text="Выйти",command=closeQuery).pack(side=RIGHT)
Button(PageThree, text='Назад', command=lambda:raise_frame(Agreement)).pack(side=LEFT,padx=5)





raise_frame(StartPage)
root.mainloop()
