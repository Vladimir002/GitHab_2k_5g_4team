import os
print("Файлы находятся:",os.getcwd())
print()
"""Создание основного файла"""
main_file = open('main_file.txt','w')
main_file.write('2\n-2\n3\n10\n5\n6\n7\n')
main_file.close()

"""Запись нечетных или четных элементов в файлы"""
main_file = open('main_file.txt','r')
f_ch = open('file_chet', 'w')
f_nch = open('file_nech', 'w')
data1 = [int(line.strip()) for line in main_file]
ch = [f_ch.write(str(i) + '\n') for i in data1 if i % 2 == 0]
nch = [f_nch.write(str(i) + '\n') for i in data1 if i % 2]
main_file.close()
f_ch.close()
f_nch.close()

"""Вывод первого файла"""
print("Элементы основного файла: ")
for i in range(len(data1)):
    print(data1[i],end = " ")
print()

"""Вывод первого и второго файла"""
f_ch = open('file_chet', 'r')
f_nch = open('file_nech', 'r')
data2 = [int(line.strip()) for line in f_ch]
data3 = [int(line.strip()) for line in f_nch]
print("Элементы файла с нечетными элементами: ")
for i in range(len(data2)):
    print(data2[i],end = " ")
print()
print("Элементы файла с четными элементами: ")
for i in range(len(data3)):
    print(data3[i],end = " ")
print()
main_file.close()
f_ch.close()
f_nch.close()