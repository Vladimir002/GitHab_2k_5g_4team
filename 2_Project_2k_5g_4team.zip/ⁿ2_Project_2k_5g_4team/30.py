f1 = open("30.txt","w")
f1.write("stroka1\n")
f1.write("stroka2\n")
f1.write("stroka3\n")
f1.write("stroka before last\n")
f1.write("stroka last")
f1.close()
f = open("30.txt", "r+")
a=[]
for c in f:
    a.append(c)

if len(a)>1:
    a[1],a[len(a)-2]=a[len(a)-2],a[1]

f.seek(0)
f.truncate(0)

for i in range(0,len(a)):
    f.write(a[i])
f.close()
