import os
print(os.getcwd())
if not os.path.exists("folder"):
    os.mkdir("folder")
os.chdir("folder")
print(os.getcwd())
f = open('data.txt', 'w') 
