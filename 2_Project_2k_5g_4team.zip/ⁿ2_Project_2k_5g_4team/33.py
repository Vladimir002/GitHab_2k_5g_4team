import os
print("Файлы находятся:",os.getcwd())

import pickle
file = open('datafile.txt', 'wb')
D = {'vova':'8', 'stepa': '6', 'primer':'9', 'vovas': '12', 'novoe':'12'}
pickle.dump(D, file)
file.close( )

file = open('datafile.txt', 'rb')
D = pickle.load(file)
print(D, type(D))
file.close( )