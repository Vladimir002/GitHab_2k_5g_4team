def gr(a):
    if a < 0:
        return -1
    elif a == 0:
        return 0
    else:
        return 1


f = open('txt.txt', 'r')

sod = f.readlines()

ch = [sod[i].split() for i in range(len(sod))]
ch = [[int(ch[i][j]) for j in range(len(ch[i]))] for i in range(len(sod))]

out = ['' for i in range(len(sod))]

for i in range(len(ch)):
    s = ch[i][0]
    z = gr(ch[i][0])
    for j in range(1, len(ch[i])):
        if z == gr(ch[i][j]):
            s = s + ch[i][j]
        else:
            out[i] = out[i] + str(s) + ' '
            s = ch[i][j]
            z = gr(ch[i][j])
    out[i] = out[i] + str(s) + '\n'

print(out)
f.close()

f = open('txt_res.txt', 'w')
f.writelines(out)
f.close()